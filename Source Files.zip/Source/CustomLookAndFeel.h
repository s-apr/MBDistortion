/*
  ==============================================================================

    CustomLookAndFeel.h
    Created: 12 May 2025 6:04:34pm
    Author:  maxbu

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>

class CustomLookAndFeel : public juce::LookAndFeel_V4
{
public:
    CustomLookAndFeel();

    //set colours and other stuff

};